#!/bin/bash

AGENT_NAME=amagent_20a.jar
AGENT_ALIAS=NIMP_AGENT_20a

fnGetPid()
{
    pids=`ps -ef | grep "${AGENT_ALIAS}" | grep -v grep |grep -v vim |grep -v tail | awk '{print $2}' `
}

start() {

    fnGetPid
    if [ "X$pids" != "X" ]; then
        echo "${AGENT_ALIAS} already running.."
    else
        echo $"Starting $AGENT_ALIAS"
        java -jar ${AGENT_NAME} ${AGENT_ALIAS} >> /dev/null 2>&1 &
#        java -jar ${AGENT_NAME} ${AGENT_ALIAS} > sys.log &
        sleep 1
        ps -ef |grep ${AGENT_ALIAS} |grep -v grep
    fi
}

stop()  {

    echo $"Shutting Down ${AGENT_ALIAS}"

    fnGetPid
    if [ "X$pids" != "X" ]; then
        kill -TERM ${pids}
    else
        echo "${AGENT_ALIAS} is not running"
    fi
    sleep 5
    ps -ef |grep ${AGENT_NAME} |grep -v grep |grep -v vi
}


fnCheck() {

    echo "checking ${AGENT_ALIAS}..."
    fnGetPid
    if [ "X$pids" != "X" ]; then
        ps -ef | grep "${AGENT_NAME}" | grep -v grep
        echo "STARTED"
    else
        echo "STOPPED"
    fi
}

case "$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  swap)
        swap
        ;;

  restart)
        stop

        sleep 1

        start
        ;;

  check | chk)
        fnCheck
        ;;
  *)
        echo $"Usage: $0 {start|stop|restart|check}"
        exit 1
esac
