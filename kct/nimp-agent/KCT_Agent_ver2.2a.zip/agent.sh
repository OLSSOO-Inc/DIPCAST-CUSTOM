#!/bin/bash

#
AGENT_NAME=amagent_22a.jar
AGENT_ALIAS=NIMP_AGENT_22a
AGENT_SHELL="agent.sh start"

fnGetPid()
{
    pids=`ps -ef | grep "${AGENT_ALIAS}" | grep -v grep |grep -v vim |grep -v tail | awk '{print $2}' `
}


fnGetShellPid()
{
    pids=`ps -ef | grep "${AGENT_SHELL}"| grep -v grep |grep -v vim |grep -v tail | awk '{print $2}'`
}


fnStart() {

    fnGetPid
    if [ "X$pids" != "X" ]; then
        echo "${AGENT_ALIAS} already running.."
    else
        echo $"Starting $AGENT_ALIAS"
        java -jar ${AGENT_NAME} ${AGENT_ALIAS} >> /dev/null 2>&1 &
#        java -jar ${AGENT_NAME} ${AGENT_ALIAS} > sys.log &
        sleep 1
        ps -ef |grep ${AGENT_ALIAS} |grep -v grep
    fi
}

fnShellStop()  {

    echo $"Shutting Down '${AGENT_SHELL}'"

    fnGetShellPid
    if [ "X$pids" != "X" ]; then
        kill -TERM ${pids}
    else
        echo "'${AGENT_SHELL}' is not running"
    fi
    sleep 2
    ps -ef |grep '"${AGENT_SHELL}"' |grep -v grep |grep -v vi
}


fnStop()  {

    echo $"Shutting Down ${AGENT_ALIAS}"

    fnGetPid
    if [ "X$pids" != "X" ]; then
        kill -TERM ${pids}
    else
        echo "${AGENT_ALIAS} is not running"
    fi
    sleep 5
    ps -ef |grep ${AGENT_NAME} |grep -v grep |grep -v vi
}


fnCheck() {

    echo "checking ${AGENT_ALIAS}..."
    fnGetPid
    if [ "X$pids" != "X" ]; then
        ps -ef | grep "${AGENT_NAME}" | grep -v grep
        echo "STARTED"
    else
        echo "STOPPED"
    fi
}


fnBootStart()
{
    while [ 1 ]
    do
        fnGetPid
        if [ "X$pids" = "X" ]; then
            echo $"Starting ${AGENT_NAME} ${AGENT_ALIAS}"
            fnStart
        fi

        sleep 30
    done

    echo $"agent.sh boot stoped"
}


case "$1" in
  start)
        fnBootStart &
        ;;
  stop)
        fnShellStop
	sleep 1
	fnStop
        ;;
  boot)
        fnBootStart
        ;;

  restart)
        fnStop

        sleep 1

        fnStart
        ;;

  check | chk)
        fnCheck
        ;;
  *)
        echo $"Usage: $0 {start|stop|restart|check}"
        exit 1
esac
