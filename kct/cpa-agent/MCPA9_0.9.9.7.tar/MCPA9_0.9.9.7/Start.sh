java -Xms32m -Xmx64m -XX:+UseG1GC -XX:MetaspaceSize=32M -XX:MaxMetaspaceSize=64M -Djdk.nio.maxCachedBufferSize=10485760 -jar ./MCPA.jar ./CPA_MMS.conf
